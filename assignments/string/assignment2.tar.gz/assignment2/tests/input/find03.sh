#!/bin/bash
./sgrep "s t" < files/microsoft.txt
